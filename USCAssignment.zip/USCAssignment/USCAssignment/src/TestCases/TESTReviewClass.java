package TestCases;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import USC_Booking.Student_reviews;

class TESTReviewClass {

	@Test
	void testReviewClass() {
		Student_reviews rc =new Student_reviews();
        String expected =" ";  //Expected
        String actual=rc.reviews_input; //Actual
        assertEquals(expected, actual);
	}

}
