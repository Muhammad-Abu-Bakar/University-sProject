package TestCases;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import USC_Booking.Montly_Report;

class TESTMonthlyReport {

	@Test
	void testRatinglist() {
		Montly_Report report =new  Montly_Report();
	}

}
