package TestCases;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import USC_Booking.Montly_Winner_Class;

class TESTChampionClass {

	@Test
	void testChampionClass() {
		Montly_Winner_Class cc = new Montly_Winner_Class();
		int exp =0; //Expected
		int act=cc.income;
		assertEquals(exp,act);
		
	}


}